import requests
import matplotlib.pyplot as plt
import pandas as pd

url = "http://127.0.0.1:8000/bridge-data/"
resp = requests.get(url)
resp.raise_for_status()
data = resp.json()

times = pd.to_datetime(data['_time'])
stress = data['stress_cycle']
pos_na = data['pos_na']

plt.figure(figsize=(10,5))
plt.plot(times, stress, label='Stress Cycle', color='blue')
plt.plot(times, pos_na, label='Pos NA', color='orange')
plt.legend()
plt.title("Bridge Structural Health Data")
plt.xlabel("Time")
plt.ylabel("Value")
plt.grid(True)
plt.tight_layout()
plt.show()
