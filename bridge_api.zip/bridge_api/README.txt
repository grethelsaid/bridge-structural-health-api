Author: Grethel Coello Said

Bridge Structural Health API
Description

Django API serving historical bridge structural health metrics from a CSV file, with a test script that fetches and plots stress_cycle and pos_na.
SQLite is used for simplicity and full reproducibility. Docker is included for easy deployment.

Install dependencies: pip install -r requirements.txt
Run Django server: python manage.py runserver
Load CSV data: python bridge/load_csv_to_db.py
Run test script to visualize data: python test_script.py

Using Docker

Build and start the container: docker-compose up --build
Migrates database, loads CSV, and starts Django on http://localhost:8000/.

Run test script: python test_script.py

API Endpoint

GET /bridge-data/ → Returns JSON:

{
  "_time": [...],
  "stress_cycle": [...],
  "pos_na": [...]
}

Notes

Data is downsampled, smoothed, and cleaned for better interpretability.

SQLite used for simplicity; can be replaced with Postgres if needed.

Docker ensures reproducibility and zero setup for evaluation.


