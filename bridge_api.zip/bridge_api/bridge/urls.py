from django.urls import path
from .views import bridge_data

urlpatterns = [
    path('bridge-data/', bridge_data, name='bridge-data'),
]
