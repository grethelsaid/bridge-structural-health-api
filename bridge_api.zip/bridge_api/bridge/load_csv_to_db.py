import pandas as pd
from bridge.models import BridgeMeasurement
import os
import django

# Configurar Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "bridge_api.settings")
django.setup()

def run():
    df = pd.read_csv("data/midspan_data.csv")
    df.columns = df.columns.str.strip()  # limpiar espacios

    # Forzar tipos correctos
    df['time'] = pd.to_datetime(df['time'], errors='coerce')
    df['Fat_cycle_bot'] = pd.to_numeric(df['Fat_cycle_bot'], errors='coerce')
    df['Pos_na'] = pd.to_numeric(df['Pos_na'], errors='coerce')

    # Eliminar filas con valores faltantes
    df = df.dropna(subset=['time','Fat_cycle_bot','Pos_na'])

    objs = [
        BridgeMeasurement(
            time=row['time'],
            stress_cycle=row['Fat_cycle_bot'],
            pos_na=row['Pos_na']
        )
        for _, row in df.iterrows()
    ]

    BridgeMeasurement.objects.bulk_create(objs, ignore_conflicts=True)
    print(f"✅ Cargadas {len(objs)} filas en la base de datos.")

if __name__ == "__main__":
    run()
