from django.shortcuts import render

# Create your views here.

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import BridgeMeasurement
import pandas as pd

@api_view(['GET'])
def bridge_data(request):
    qs = BridgeMeasurement.objects.all().order_by('time').values('time','stress_cycle','pos_na')
    df = pd.DataFrame.from_records(qs)

    if df.empty:
        return Response({"_time": [], "stress_cycle": [], "pos_na": []})

    df['time'] = pd.to_datetime(df['time'])
    df = df.set_index('time').sort_index()

    # Downsampling 1 minuto
    df = df.resample('1T').mean()

    # Eliminación de outliers y suavizado
    for col in ['stress_cycle', 'pos_na']:
        z = (df[col] - df[col].mean()) / df[col].std(ddof=0)
        df[col] = df[col].where(z.abs() <= 3)
        df[col] = df[col].interpolate(limit_direction='both')
        df[col] = df[col].rolling(window=5, center=True, min_periods=1).mean()

    data = {
        "_time": [t.isoformat() for t in df.index.to_pydatetime()],
        "stress_cycle": df['stress_cycle'].round(3).tolist(),
        "pos_na": df['pos_na'].round(3).tolist()
    }

    return Response(data)

