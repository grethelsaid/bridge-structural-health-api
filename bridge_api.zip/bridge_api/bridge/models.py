# models here.
from django.db import models

class BridgeMeasurement(models.Model):
    time = models.DateTimeField(primary_key=True)
    stress_cycle = models.FloatField()
    pos_na = models.FloatField()

    class Meta:
        db_table = "bridge_measurement"

    def __str__(self):
        return f"{self.time} - {self.stress_cycle:.2f}, {self.pos_na:.2f}"
